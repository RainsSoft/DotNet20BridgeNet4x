#region LGPL License

/*
Axiom Graphics Engine Library
Copyright � 2003-2011 Axiom Project Team

The overall design, and a majority of the core engine and rendering code 
contained within this library is a derivative of the open source Object Oriented 
Graphics Engine OGRE, which can be found at http://ogre.sourceforge.net.  
Many thanks to the OGRE team for maintaining such a high quality project.

The math library included in this project, in addition to being a derivative of
the works of Ogre, also include derivative work of the free portion of the 
Wild Magic mathematics source code that is distributed with the excellent
book Game Engine Design.
http://www.wild-magic.com/

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#endregion

#region SVN Version Information

// <file>
//     <license see="http://axiom3d.net/wiki/index.php/license.txt"/>
//     <id value="$Id$"/>
// </file>

#endregion SVN Version Information

#region Namespace Declarations

using System;

#endregion Namespace Declarations

namespace Axiom.Math
{
    /// <summary>
    ///		A standard sphere, used mostly for bounds checking.
    /// </summary>
    /// <remarks>
    ///		A sphere in math texts is normally represented by the function
    ///		x^2 + y^2 + z^2 = r^2 (for sphere's centered on the origin). We store spheres
    ///		simply as a center point and a radius.
    /// </remarks>
    public sealed class Sphere
    {
        #region Protected member variables

        private Real radius;
        private Vector3 center;

        #endregion

        #region Constructors

        /// <summary>
        ///		Creates a unit sphere centered at the origin.
        /// </summary>
        public Sphere()
        {
            this.radius = 1.0f;
            this.center = Vector3.Zero;
        }

        /// <summary>
        /// Creates an arbitrary spehere.
        /// </summary>
        /// <param name="center">Center point of the sphere.</param>
        /// <param name="radius">Radius of the sphere.</param>
        public Sphere(Vector3 center, Real radius)
        {
            this.center = center;
            this.radius = radius;
        }

        #endregion

        #region Properties

        /// <summary>
        ///		Gets/Sets the center of the sphere.
        /// </summary>
        public Vector3 Center
        {
            get
            {
                return this.center;
            }
            set
            {
                this.center = value;
            }
        }

        /// <summary>
        ///		Gets/Sets the radius of the sphere.
        /// </summary>
        public Real Radius
        {
            get
            {
                return this.radius;
            }
            set
            {
                this.radius = value;
            }
        }

        #endregion

        #region Intersection methods

        public static bool operator ==(Sphere sphere1, Sphere sphere2)
        {
            return sphere1.center == sphere2.center && sphere1.radius == sphere2.radius;
        }

        public static bool operator !=(Sphere sphere1, Sphere sphere2)
        {
            return sphere1.center != sphere2.center || sphere1.radius != sphere2.radius;
        }

        public override bool Equals(object obj)
        {
            return obj is Sphere && this == (Sphere)obj;
        }

        public override int GetHashCode()
        {
            return this.center.GetHashCode() ^ this.radius.GetHashCode();
        }


        /// <summary>
        ///		Tests for intersection between this sphere and another sphere.
        /// </summary>
        /// <param name="sphere">Other sphere.</param>
        /// <returns>True if the spheres intersect, false otherwise.</returns>
        public bool Intersects(Sphere sphere)
        {
            return ((sphere.center - this.center).Length <= (sphere.radius + this.radius));
        }

        /// <summary>
        ///		Returns whether or not this sphere interects a box.
        /// </summary>
        /// <param name="box"></param>
        /// <returns>True if the box intersects, false otherwise.</returns>
        public bool Intersects(AxisAlignedBox box)
        {
            return Utility.Intersects(this, box);
        }

        /// <summary>
        ///		Returns whether or not this sphere interects a plane.
        /// </summary>
        /// <param name="plane"></param>
        /// <returns>True if the plane intersects, false otherwise.</returns>
        public bool Intersects(Plane plane)
        {
            return Utility.Intersects(this, plane);
        }

        /// <summary>
        ///		Returns whether or not this sphere interects a Vector3.
        /// </summary>
        /// <param name="vector"></param>
        /// <returns>True if the vector intersects, false otherwise.</returns>
        public bool Intersects(Vector3 vector)
        {
            return (vector - this.center).Length <= this.radius;
        }

        #endregion Intersection methods
    }
}