﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetCross.Runtime.CompilerServices {
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Constructor | AttributeTargets.Struct | AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    internal sealed class NonVersionableAttribute : Attribute {
        // Methods
        public NonVersionableAttribute() {

        }
    }



}
