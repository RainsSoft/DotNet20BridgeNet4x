﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.Serialization.Formatters.Binary;

namespace DotNetCross.Runtime.CompilerServices {


    /// <summary>
    /// A type is an unmanaged type if it's any of the following types: [ 如果类型是以下任一类型，则类型为非托管类型：]
    ///sbyte, byte, short, ushort, int, uint, long, ulong, nint, nuint, char, float, double, decimal, or bool
    ///Any enum type [任何枚举类型]
    ///Any pointer type[任何指针类型]
    ///Any user-defined struct type that contains fields of unmanaged types only. [仅包含非托管类型字段的任何用户定义结构类型。]
    ///You can use the unmanaged constraint to specify that a type parameter is a non-pointer, non-nullable unmanaged type. [可以使用非托管约束指定类型参数是非指针、不可为空的非托管类型。]
    /// </summary>
    public unsafe static class SizeOf_T_ {// Extensions {
        /// <summary>
        /// 如果是泛型class类，通常返回IntPtr.Size-[值4]，如果是StructLayout(LayoutKind...)结构布局且checkClassStructLayout==false，则与Marshal.SizeOf(class)返回的值不一样
        /// 如果是泛型struct结构体,则与Marshal.SizeOf(new T()/default(T))返回结果一致
        /// </summary>
        /// <typeparam name="T">具体类型</typeparam>
        /// <param name="checkClassStructLayout">检查class的StructLayout内存布局,如果为true且泛型类型是class,则尝试取Marshal.SizeOf(class)的尺寸</param>
        /// <param name="AOT"></param>
        /// <returns></returns>
        public static int SizeOf<T>(bool checkClassStructLayout = false, bool AOT = false) {
            return SizeOf(typeof(T), null, checkClassStructLayout, AOT);
        }

        public static int SizeOf(this Type type, FieldInfo field, bool checkClassStructLayout, bool AOT = false) {
            if(IsGenericType(type)) {
                return SizeOfInGenericMap(type);
            }
            bool isUnManaged = type.IsUnManaged();
            byte canMarshalSize = 0;
            if(isUnManaged) {
                canMarshalSize = 1;
                try {
                    int sz = System.Runtime.InteropServices.Marshal.SizeOf(type);
                    canMarshalSize = 2;
                    return sz;
                }
                catch(Exception ee) {
                    //不能使用Marshal.SizeOf,但是计算出来后可以加入缓存                    
                }
            }
            else {
                if(checkClassStructLayout &&
                    (type.IsExplicitLayout || type.IsLayoutSequential)) {
                    try {
                        int sz = System.Runtime.InteropServices.Marshal.SizeOf(type);
                        //canMarshalSize = 2;
                        return sz;
                    }
                    catch(Exception ee) {
                        //不能使用Marshal.SizeOf,但是计算出来后可以加入缓存                    
                    }
                }
            }
            if(AOT) {
                //静态编译
                if(type.IsPrimitive) {
                    if(type == typeof(byte) || type == typeof(SByte) || type == typeof(bool))
                        return 1;

                    if(type == typeof(short) || type == typeof(ushort) || type == typeof(char))
                        return 2;

                    if(type == typeof(int) || type == typeof(uint) || type == typeof(float))
                        return 4;

                    if(type == typeof(long) || type == typeof(ulong) || type == typeof(double))
                        ////这里指针可能有问题，如果是32位系统呢(4)？64位系统(8)
                        //||type == typeof(IntPtr) 
                        //||type == typeof(UIntPtr))
                        return 8;
                    if(type == typeof(IntPtr)) {
                        return IntPtr.Size;
                    }
                    if(type == typeof(UIntPtr)) {
                        return UIntPtr.Size;
                    }
                }
                else {
                    if(type.IsValueType) {
                        //return (from fld in
                        //            type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                        //        select fld.FieldType.Size(fld)).Sum();
                        int sizeVT = 0;
                        var fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        foreach(var fld in fields) {
                            sizeVT += fld.FieldType.SizeOf(fld, true);
                        }
                        if(canMarshalSize == 1) {
                            //IsUnManaged使用Marshal.SizeOf计算错误,这里计算出来后可以加入缓存   
                            genericSizes.Add(type, sizeVT);

                        }
                        return sizeVT;
                    }

                    if(field != null) {
                        object[] attributes = field.GetCustomAttributes(typeof(MarshalAsAttribute), false);
                        if(attributes != null && attributes.Length > 0) {

                            var marshal = (MarshalAsAttribute)attributes[0];
                            if(type.IsArray)
                                return marshal.SizeConst * type.GetElementType().SizeOf(null, checkClassStructLayout, AOT);//Size();
                            if(type == typeof(string))
                                return marshal.SizeConst;
                        }
                    }
                }
                // 1.值类型泛型类，可以用
                //whereT : unmanaged 和sizeof(T)配合使用
                //或者直接使用 Unsafe.Sizeof(T)
                //2.非值类型泛型类，可用
                //Marshal.SizeOf(T)
                //计算T类型占用的内存大小，如果T是一个引用类型，那么计算的是该引用类型本身占用的内存大小（通常是一个指针大小），而不是引用类型指向的对象的大小
                return IntPtr.Size;
                //throw new Exception(type.ToString() + " is not IsUnManaged type,cann't SizeOf(...) ");
                // we don't know what   real size is so assume it's 16 bytes.
                // Microsoft recommends that structs shouldn't be bigger than this
                // anyway so it's unlikely that types will be bigger than this.
                return 16;
            }
            else {
                //支持动态编译
                var dynamicMethod = new DynamicMethod("SizeOf", typeof(int), Type.EmptyTypes);
                var generator = dynamicMethod.GetILGenerator();

                generator.Emit(OpCodes.Sizeof, type);
                generator.Emit(OpCodes.Ret);

                var function = (Func<int>)dynamicMethod.CreateDelegate(typeof(Func<int>));
                int sz = function();
                if(canMarshalSize == 1) {
                    //IsUnManaged使用Marshal.SizeOf计算错误,这里计算出来后可以加入缓存   
                    genericSizes.Add(type, sz);
                }
                return sz;
            }
        }
        /*
        static int Size(this Type type) {
            return Size(type, null);
        }

        static int Size(this Type type, FieldInfo field) {
#if SILVERLIGHT || WINDOWS_PHONE
			if ( type.IsPrimitive )
			{
				if ( type == typeof( byte ) || type == typeof( SByte ) || type == typeof( bool ) )
					return 1;

				if ( type == typeof( short ) || type == typeof( ushort ) || type == typeof( char ) )
					return 2;

				if ( type == typeof( int ) || type == typeof( uint ) || type == typeof( float ) )
					return 4;

				if ( type == typeof( long ) || type == typeof( ulong ) || type == typeof( double ) || type == typeof( IntPtr ) || type == typeof( UIntPtr ) )
					return 8;
			}
			else
			{
                if (type.IsValueType) {
                    //return (from fld in
                    //            type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                    //        select fld.FieldType.Size(fld)).Sum();
                    int sizeVT = 0;
                    var fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    foreach (var fld in fields) {
                        sizeVT += fld.FieldType.SizeOf(fld, true);
                    }
                    return sizeVT;
                }

				if ( field != null )
				{
					var attributes = field.GetCustomAttributes( typeof( MarshalAsAttribute ), false );
					var marshal = (MarshalAsAttribute)attributes[ 0 ];
					if ( type.IsArray )
						return marshal.SizeConst * type.GetElementType().Size();
					if ( type == typeof( string ) )
						return marshal.SizeConst;
				}
			}
#endif
            return Marshal.SizeOf(type);
        }

        */
        #region Fields


        #endregion


        /// <summary>
        /// A lookup of type sizes. Used instead of Marshal.SizeOf() which has additional
        /// overhead, but also is compatible with generic functions for simplified code.
        /// </summary>
        readonly static Dictionary<Type, int> genericSizes = new Dictionary<Type, int>()
        {
            { typeof(bool),     sizeof(bool) },
            { typeof(float),    sizeof(float) },
            { typeof(double),   sizeof(double) },
            { typeof(sbyte),    sizeof(sbyte) },
            { typeof(byte),     sizeof(byte) },
            { typeof(short),    sizeof(short) },
            { typeof(ushort),   sizeof(ushort) },
            { typeof(int),      sizeof(int) },
            { typeof(uint),     sizeof(uint) },
            { typeof(ulong),    sizeof(ulong) },
            { typeof(long),     sizeof(long) },
            //补充
            { typeof(char), sizeof(char) },
            { typeof(decimal), sizeof(decimal) },
			// common value types
			{ typeof(IntPtr), IntPtr.Size },
            { typeof(UIntPtr), UIntPtr.Size },
            { typeof(Guid), 16 },
            { typeof(DateTime), 8 },
            { typeof(TimeSpan), 8 }
        };

        /// <summary>
        /// Get the wire-size (in bytes) of a type supported by flatbuffers.
        /// </summary>
        /// <param name="t">The type to get the wire size of</param>
        /// <returns></returns>
        static int SizeOfInGenericMapT<T>() {
            return genericSizes[typeof(T)];
        }
        static int SizeOfInGenericMap(Type type) {
            return genericSizes[type];
        }
        public static bool IsStruct(Type type) {
            return type.IsValueType && !type.IsEnum;
            return type.IsValueType && !type.IsEnum && !type.IsPrimitive;
        }

        /// <summary>
        /// Checks if the Type provided is supported as scalar value
        /// </summary>
        /// <typeparam name="T">The Type to check</typeparam>
        /// <returns>True if the type is a scalar type that is supported, falsed otherwise</returns>
        static bool IsGenericType<T>() {
            return genericSizes.ContainsKey(typeof(T));
        }
        static bool IsGenericType(Type type) {
            return genericSizes.ContainsKey(type);
        }

        #region Unmanaged
        private static Dictionary<Type, bool> _unmanagedCachedTypes = new Dictionary<Type, bool>();

#if NET_4_0
        
        private class UnmanagedChecker<T> where T : unmanaged
        {
            //需要.net4.0
        }
        public static bool IsUnmanaged<T>() {
            return IsUnmanaged(typeof(T));
        }
        public static bool IsUnmanaged(Type type) {
            //https://github.com/Sonozuki/NovaEngine/blob/main/NovaEngine/Extensions/TypeExtensions.cs
            try {
                // if   type is not unmanaged, MakeGenericType will throw
                //   due 到 type restrictions 于 UnmanagedChecker
                typeof(UnmanagedChecker<>).MakeGenericType(type);
                _unmanagedCachedTypes.Add(type, true);
                return true;
            }
            catch {
                _unmanagedCachedTypes.Add(type, false);
                return false;
            }
        }
        
#else
        public static bool IsUnManaged(this Type t) {
            bool result;
            if(_unmanagedCachedTypes.TryGetValue(t, out result))
                return result;

            else if(t.IsPrimitive || t.IsPointer || t.IsEnum)
                result = true;
            else if(t.IsGenericType || !t.IsValueType || Nullable.GetUnderlyingType(t) != null) {
                //增加Nullable判断
                result = false;
            }
            else {
                // result = t.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).All(x => x.FieldType.IsUnManaged());
                var fieldInfos = t.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                result = true;
                foreach(var fieldInfo in fieldInfos) {
                    if(!fieldInfo.FieldType.IsUnManaged()) {
                        result = false;
                        break;
                    }
                }
            }

            _unmanagedCachedTypes.Add(t, result);
            return result;
            //https://github.com/dotnet/dotNext/blob/master/src/DotNext/Reflection/TypeExtensions.cs
            //if(type.IsGenericType ||
            //  type.IsGenericTypeDefinition ||
            //  type.IsGenericParameter) {
            //    // foreach(var attribute in type.GetCustomAttributesData()) {
            //    //if(attribute.AttributeType.FullName == IsUnmanagedAttributeName)
            //    //    return true;
            //    foreach(var attribute in type.GetCustomAttributes(true)) {
            //        if((attribute as Attribute).GetType().FullName == IsUnmanagedAttributeName) {
            //            return true;
            //        }
            //    }
            //    return false;
            //}
            //if(type.IsPrimitive || type.IsPointer || type.IsEnum) {
            //    return true;
            //}
            //if(type.IsValueType) {
            //    // check all fields
            //    foreach(var field in type.GetFields(BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.NonPublic)) {
            //        if(!field.FieldType.IsUnmanaged())
            //            return false;

            //    }
            //    return true;
            //}
            //return false;
        }
#endif
        #endregion

        #region Layout
        //public static List<object> GetStructFields(object obj) {
        //    List<object> fields = new List<object>();
        //    Type type = obj.GetType();
        //    foreach(var v in type.GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)) {
        //        Type fieldType = v.FieldType;
        //        object value = v.GetValue(obj);
        //        if(Attribute.IsDefined(v, typeof(MemoryAttribute)) && ((MemoryAttribute)v.GetCustomAttribute(typeof(MemoryAttribute))).Ignore)
        //            continue;
        //        if(IsStruct(fieldType)) {
        //            fields.AddRange(GetStructFields(value));

        //        }
        //        else if(fieldType.IsArray) {

        //            Array arr = (Array)value;

        //            for(int i = 0; i < arr.Length; i++) {
        //                object arrayValue = arr.GetValue(i);

        //                if(!isAllowedType(fieldType.GetElementType())) {
        //                    fields.AddRange(GetStructFields(arrayValue));
        //                    continue;
        //                }
        //                fields.Add(arrayValue);
        //            }
        //        }
        //        else if(fieldType.IsEnum) {
        //            Type enumType = fieldType.GetEnumUnderlyingType();
        //            fields.Add(Convert.ChangeType(value, enumType));
        //        }
        //        else {
        //            fields.Add(value);
        //        }
        //    }
        //    return fields;
        //}
        //static bool isAllowedType(Type type) {

        //    return !type.IsGenericType && !type.IsArray && !type.IsEnum && !IsStruct(type);
        //}

        //public static int GetStructFieldSize(object obj) {
        //    int size = 0;
        //    List<object> fields = GetStructFields(obj);
        //    for(int i = 0; i < fields.Count; i++) {
        //        size += Marshal.SizeOf(fields[i]);
        //    }
        //    return size;
        //}
        //
        /// <summary>
        /// 结构元素
        /// </summary>
        public struct StructElement {
            public IntPtr name;
            public TypeCode type;
            public short offset;
            public short size;

            public string Name {
                get {
                    return Marshal.PtrToStringAnsi(name);
                }
            }
        }

        readonly static int[] size = new int[]
        {
            0, 0, 0,
            sizeof(bool), sizeof(char), sizeof(sbyte), sizeof(byte),
            sizeof(short), sizeof(ushort), sizeof(int), sizeof(uint),
            sizeof(long), sizeof(ulong), sizeof(float), sizeof(double),
            sizeof(decimal), sizeof(DateTime), 0, sizeof(int) + sizeof(IntPtr)
        };

        public static StructElement[] GetLayout(this Type type, out int size) {
            if(!type.IsUnManaged()) {
                size = 0;
                return null;
            }

            var fieldInfos = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            int len = fieldInfos.Length;
            StructElement[] layout = new StructElement[len];
            size = 0;
            for(int i = 0; i < len; i++) {
                var fieldInfo = fieldInfos[i];
                //引用局部变量指的是在变量声明时使用ref关键字（或者使用ref readonly表示未只读），表示这个变量是另一个变量的引用，而不是值对象的赋值，或者引用类型的地址，这个引用可以理解为一个别名，操作这个别名对象与操作原始对象无异！　
                //ref var e = ref layout[i];
                //e.name = Marshal.StringToHGlobalAnsi(fieldInfo.Name);
                //e.type = GetTypeCode(fieldInfo.FieldType);
                //e.offset = (short)Marshal.OffsetOf(type, fieldInfo.Name);
                //e.size = (short)GetSize(fieldInfo.FieldType);
                //Debug.Assert(e.size != 0);
                //size += e.size;             
                layout[i].name = Marshal.StringToHGlobalAnsi(fieldInfo.Name);
                layout[i].type = GetTypeCode(fieldInfo.FieldType);
                layout[i].offset = (short)Marshal.OffsetOf(type, fieldInfo.Name);
                layout[i].size = (short)GetSize(fieldInfo.FieldType);
                Debug.Assert(layout[i].size != 0);
                size += layout[i].size;
            }

            return layout;
        }

        public static TypeCode GetTypeCode(Type type) {
            if(type == typeof(IntPtr)) {
                return TypeCode.Int64;
            }
            else if(type == typeof(UIntPtr)) {
                return TypeCode.UInt64;
            }

            return Type.GetTypeCode(type);
        }

        static int GetSize(Type type) {
            return size[(int)GetTypeCode(type)];
        }

        public static bool ShouldExport(this Type t) {
            if(t.IsByRef || t.IsPointer) {
                return false;
            }

            return true;
        }

        private static Dictionary<Type, string> _defaultDictionary = new Dictionary<System.Type, string>
        {
            {typeof(int), "int"},
            {typeof(uint), "uint"},
            {typeof(long), "long"},
            {typeof(ulong), "ulong"},
            {typeof(short), "short"},
            {typeof(ushort), "ushort"},
            {typeof(byte), "byte"},
            {typeof(sbyte), "sbyte"},
            {typeof(bool), "bool"},
            {typeof(float), "float"},
            {typeof(double), "double"},
            {typeof(decimal), "decimal"},
            {typeof(char), "char"},
            {typeof(string), "string"},
            {typeof(object), "object"},
            {typeof(void), "void"}
        };

        public static string GetFriendlyName(this Type type, Dictionary<Type, string> translations) {
            if(translations.ContainsKey(type))
                return translations[type];
            else if(type.IsArray)
                return GetFriendlyName(type.GetElementType(), translations) + "[]";
            else if(type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                return type.GetGenericArguments()[0].GetFriendlyName() + "?";
            else if(type.IsGenericType)
                //return type.Name.Split('`')[0] + "<" + string.Join(", ", type.GetGenericArguments().Select(x => GetFriendlyName(x)).ToArray()) + ">";
                return type.Name.Split('`')[0] + "<" + string.Join(", ", Select(type.GetGenericArguments(), x => GetFriendlyName(x)).ToArray()) + ">";
            else
                return type.FullName.Replace("+", ".");
        }

        public static string GetFriendlyName(this Type type) {
            return type.GetFriendlyName(_defaultDictionary);
        }
        static List<string> Select(Type[] args, Func<Type, string> func) {
            List<string> os = new List<string>();
            //int counter = 0;
            foreach(var element in args) {
                //yield return selector(element, counter);
                os.Add(func(element));
                //counter++;
            }
            return os;
        }
        #endregion

        #region calcul obj size
        //public static long GetSizeInSerializeBytes(object obj) {
        //            if(memoryBinaryFormatterSerialize) {
        //                var ms = new MemoryStream();
        //                var formatter = new BinaryFormatter();
        //                formatter.Serialize(ms, obj);
        //#if DEBUG
        //                //使用序列化计算出来的是不准确的，比实际大很多             
        //                //ms.Position = 0;
        //                //byte[] buf = ms.ToArray();
        //#endif
        //                return ms.Length;
        //            }
        //            else {
        //                  比实际要大一点
        //                  return MemoryUsage.SizeInBytes(obj);
        //             }
        //}
        ///// <summary>
        /////此方法将为您提供对象实例大小的近似值（以 bytes1 为单位）。
        /////如果您想知道包含字符串属性的类的大小，则需要（在 32 位系统上）：
        /////8 个字节用于内部数据
        /////4 个字节用于字符串引用
        /////4 字节未使用空间（达到内存管理器可以处理的最小 16 字节）
        /////通常包含整数属性的类需要：
        /////8 个字节用于内部数据 2。
        ///// </summary>
        ///// <param name="obj"></param>
        ///// <returns></returns>
        //public static unsafe int CalcObjSize(object obj, bool runtimeTypeHandle) {
        //    if(runtimeTypeHandle) {
        //        RuntimeTypeHandle th = obj.GetType().TypeHandle;
        //        int size = *(*(int**)&th + 1);
        //        //结果不正常
        //        return size;
        //    }
        //    return GetObjectSize(obj);
        //}
        //static int GetObjectSize(object obj) {
        //    FieldInfo[] fields = obj.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        //    int size = 0;
        //    foreach(FieldInfo field in fields) {
        //        size += GetFieldSize(obj, field, field.FieldType);
        //    }
        //    return size;
        //}
        //private static int GetFieldSize(object obj, FieldInfo field, Type type) {
        //    //结果不正常
        //    if(type.IsValueType) {
        //        return Marshal.SizeOf(type);
        //    }
        //    else if(type.IsArray) {
        //        object value = field.GetValue(obj);
        //        //Array arr = (Array)value;
        //        return GetFieldSize(obj, field, type.GetElementType()) * ((Array)value).Length;
        //    }
        //    else {
        //        return GetObjectSize(Activator.CreateInstance(type));
        //    }
        //}
        #endregion
    }
    /// <summary>
    /// 计算托管对象使用的内存，（计算不是很准，比实际大一点）
    /// </summary>
    public static class MemoryUsage {
        /// <summary>
        ///   actual, exposed method:
        ///   计算不是很准，比实际大一点
        /// </summary>
        public static Int64 SizeInBytes(params Object[] _someObjects) {
            Size temp = new Size(_someObjects);
            Int64 tempSize = temp.GetSizeInBytes();
            return tempSize;
        }

        /// <summary>
        /// Nice way 到 calculate   size of managed object!
        /// 计算不是很准，比实际大一点
        /// </summary>
        internal class Size {
            static private readonly Int32 m_PointerSize = (IntPtr.Size == 4) ? sizeof(Int32) : sizeof(Int64); //Environment.Is64BitOperatingSystem ? sizeof(Int64) : sizeof(Int32);

            //private readonly Int32 m_PointerSize = Environment.Is64BitOperatingSystem ? sizeof(Int64) : sizeof(Int32);
            private Int32 m_ExistingReferenceCount;
            private readonly Object[] m_Objs;
            private readonly HashSet<Object> m_References;

            public Size(params Object[] _objs) {
                m_Objs = _objs;

                m_References = new HashSet<Object>();

                foreach(Object obj in m_Objs) {
                    m_References.Add(obj);
                }
            }

            public Int64 GetSizeInBytes() {
                Int64 size = 0;

                foreach(Object obj in m_Objs) {
                    size += GetSizeInBytes(m_Objs);
                }

                return size;
            }
            /// <summary>
            ///   core functionality. Recurrently calls itself when 一个 object appears 到 have fields 
            /// until all fields have been  visited, 或 were "visited" (calculated) already.
            /// </summary>
            /// <returns></returns>
            public Int64 GetSizeInBytes<T>(T _obj) {
                if(ReferenceEquals(_obj, null)) {
                    return m_PointerSize;
                    //return sizeof(Int32);
                }

                Type type = _obj.GetType();

                if(type.IsPrimitive) {
                    var tc = Type.GetTypeCode(type);
                    switch(tc) {
                        case TypeCode.Boolean:
                            return sizeof(Boolean);
                            break;
                        case TypeCode.Byte:
                            return sizeof(Byte);
                            break;
                        case TypeCode.SByte:
                            return sizeof(SByte);
                            break;
                        case TypeCode.Char:
                            return sizeof(Char);
                            break;
                        case TypeCode.Single:
                            return sizeof(Single);
                            break;
                        case TypeCode.Double:
                            return sizeof(Double);
                            break;
                        case TypeCode.Int16:
                            return sizeof(Int16);
                            break;
                        case TypeCode.UInt16:
                            return sizeof(UInt16);
                            break;
                        case TypeCode.Int32:
                            return sizeof(Int32);
                            break;
                        case TypeCode.UInt32:
                            return sizeof(UInt32);
                            break;
                        case TypeCode.Int64:
                            return sizeof(Int64);
                            break;
                        case TypeCode.UInt64:
                            return sizeof(UInt64);
                            break;
                        default:
                            return sizeof(Int64);
                            break;
                    }
                    //          return Type.GetTypeCode(type) switch

                    //        {

                    //                  TypeCode.Boolean => sizeof(Boolean),
                    //TypeCode.Byte => sizeof(Byte),
                    //TypeCode.SByte => sizeof(SByte),
                    //TypeCode.Char => sizeof(Char),
                    //TypeCode.Single => sizeof(Single),
                    //TypeCode.Double => sizeof(Double),
                    //TypeCode.Int16 => sizeof(Int16),
                    //TypeCode.UInt16 => sizeof(UInt16),
                    //TypeCode.Int32 => sizeof(Int32),
                    //TypeCode.UInt32 => sizeof(UInt32),
                    //TypeCode.Int64 => sizeof(Int64),
                    //TypeCode.UInt64 => sizeof(UInt64),
                    //_ => sizeof(Int64)

                    //              };
                }

                if(_obj is Decimal) {
                    return sizeof(Decimal);
                }

                if(_obj is String) {
                    string s = _obj as string;
                    return sizeof(Char) * s.Length;
                }

                if(type.IsEnum) {
                    Type underlyingType = Enum.GetUnderlyingType(type);
                    return Marshal.SizeOf(underlyingType);
                }

                if(type.IsArray) {
                    Int64 size = m_PointerSize;
                    IEnumerable casted = (IEnumerable)_obj;
                    foreach(Object item in casted) {
                        size += GetSizeInBytes(item);
                    }

                    return size;
                }

                if(_obj is Pointer) {
                    return m_PointerSize;
                }

                {
                    Int64 size = m_PointerSize;
                    FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);// (BindingFlags.Instance | BindingFlags.Public |BindingFlags.NonPublic | BindingFlags.DeclaredOnly);
                    if(fields != null) {
                        foreach(FieldInfo field in fields) {
                            Object tempVal = field.GetValue(_obj);
                            size += GetSizeInBytes(tempVal);
                            if(!m_References.Contains(tempVal)) {
                                m_References.Add(tempVal);
                                //size += GetSizeInBytes(tempVal);
                            }
                            else {
                                ++m_ExistingReferenceCount;
                            }
                        }

                    }
                    return size;

                    //Int64 size = 0;
                    //Type t = type;
                    //while(t != null) {
                    //    size += m_PointerSize;
                    //    FieldInfo[] fields = t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);// (BindingFlags.Instance | BindingFlags.Public |BindingFlags.NonPublic | BindingFlags.DeclaredOnly);
                    //    foreach(FieldInfo field in fields) {
                    //        Object tempVal = field.GetValue(_obj);
                    //        if(!m_References.Contains(tempVal)) {
                    //            m_References.Add(tempVal);
                    //            size += GetSizeInBytes(tempVal);
                    //        }
                    //        else {
                    //            ++m_ExistingReferenceCount;
                    //        }
                    //    }

                    //    t = t.BaseType;
                    //}

                    //return size;
                }

                ///// <summary>
                ///// Nice way 到 calculate   size of managed object!
                ///// 结果不符合预期
                //https://github.com/Arganancer/PathfindingBenchmark_Console/blob/master/Program/Utilities/MemoryUsage.cs


            }

        }
    }
    //    /// <summary>
    //    /// Utility class.
    //    /// </summary>
    //    public static class SizeOf_T_ {
    //        /// <summary>
    //        /// Return the sizeof a struct from a CLR. Equivalent to sizeof operator but works on generics too.
    //        /// </summary>
    //        /// <typeparam name="T">a struct to evaluate</typeparam>
    //        /// <returns>sizeof this struct</returns>
    //        //public static int SizeOf<T>() where T : struct {
    //        //    int size = Marshal.SizeOf(typeof(T));
    //        //    return size;           
    //        //    //return Interop.SizeOf<T>();
    //        //}
    //        public static int SizeOf<T>() {
    //            var type = typeof(T);
    //#if AOT
    //            if (type.IsClass) {
    //                return IntPtr.Size;
    //            }
    //            if (type.IsEnum) {
    //                return SizeOf(Enum.GetUnderlyingType(type));
    //            }
    //            int size1;
    //            if (genericSizes.TryGetValue(type, out size1)) {
    //                return size1;
    //            }
    //            if (type.IsValueType) {
    //                return Marshal.SizeOf(type);
    //            }
    //            return Marshal.SizeOf(default(T));
    //            //return SizeOf(typeof(T));
    //#else
    //            //

    //            if(type.IsClass) {
    //                return IntPtr.Size;
    //            }
    //            if(type.IsEnum) {
    //                return SizeOf(Enum.GetUnderlyingType(type));
    //            }
    //            int size;
    //            if(genericSizes.TryGetValue(type, out size)) {
    //                return size;
    //            }
    //            //
    //            int overhead;
    //            if(type.IsGenericType && _simpleGenericTypes.TryGetValue(type.GetGenericTypeDefinition(), out overhead)) {
    //                int result = 0;
    //                foreach(var arg in type.GetGenericArguments()) {
    //                    result += SizeOf(arg);
    //                }
    //                return result + overhead;
    //            }
    //            //if(type.IsGenericType && _simpleGenericTypes.TryGetValue(type, out overhead)) {
    //            //    return overhead;
    //            //}
    //            return SizeOf(type);
    //            // we don't know what   real size is so assume it's 16 bytes.
    //            // Microsoft recommends that structs shouldn't be bigger than this
    //            // anyway so it's unlikely that types will be bigger than this.
    //            return 16;
    //#endif
    //        }
    //        public delegate T Func<T>();
    //        public static int SizeOf(this Type type) {
    //#if AOT
    //            if (type.IsClass) {
    //                return IntPtr.Size;
    //            }
    //            if (type.IsEnum) {
    //                return SizeOf(Enum.GetUnderlyingType(type));
    //            }
    //            int size1;
    //            if (genericSizes.TryGetValue(type, out size1)) {
    //                return size1;
    //            }
    //            if (type.IsValueType) {
    //                return Marshal.SizeOf(type);
    //            }
    //            return Marshal.SizeOf(type);
    //#endif
    //            int sizeI = 0;
    //            if(_simpleGenericTypes.TryGetValue(type, out sizeI)) {
    //                return sizeI;
    //            }
    //            var dynamicMethod = new DynamicMethod("SizeOf", typeof(int), Type.EmptyTypes);
    //            var generator = dynamicMethod.GetILGenerator();

    //            generator.Emit(OpCodes.Sizeof, type);
    //            generator.Emit(OpCodes.Ret);

    //            var function = (Func<int>)dynamicMethod.CreateDelegate(typeof(Func<int>));
    //            sizeI = function();
    //            _simpleGenericTypes.Add(type, sizeI);
    //            return sizeI;
    //        }
    //        /// <summary>
    //        /// A lookup of type sizes. Used instead of Marshal.SizeOf() which has additional
    //        /// overhead, but also is compatible with generic functions for simplified code.
    //        /// </summary>
    //        private static Dictionary<Type, int> genericSizes = new Dictionary<Type, int>()
    //        {
    //            { typeof(bool),     sizeof(bool) },
    //            { typeof(float),    sizeof(float) },
    //            { typeof(double),   sizeof(double) },
    //            { typeof(sbyte),    sizeof(sbyte) },
    //            { typeof(byte),     sizeof(byte) },
    //            { typeof(short),    sizeof(short) },
    //            { typeof(ushort),   sizeof(ushort) },
    //            { typeof(int),      sizeof(int) },
    //            { typeof(uint),     sizeof(uint) },
    //            { typeof(ulong),    sizeof(ulong) },
    //            { typeof(long),     sizeof(long) },
    //            { typeof(char), sizeof(char) },
    //            { typeof(decimal), sizeof(decimal) },
    //			// common value types
    //			{ typeof(IntPtr), IntPtr.Size },
    //            { typeof(Guid), 16 },
    //            { typeof(DateTime), 8 },
    //            { typeof(TimeSpan), 8 }
    //        };
    //        private static Dictionary<Type, int> _simpleGenericTypes = new Dictionary<Type, int>();
    //    }

    //public static class UnmanagedTypeExtensions {
    //    private static readonly Dictionary<Type, bool> _cache = new Dictionary<Type, bool>();

    //    public static bool IsUnmanaged(this Type t) {
    //        var result = false;

    //        if(_cache.ContainsKey(t))
    //            return _cache[t];

    //        if(t.IsPrimitive || t.IsPointer || t.IsEnum)
    //            result = true;
    //        else
    //            if(t.IsValueType && t.IsGenericType) {
    //            var areGenericTypesAllBlittable = t.GenericTypeArguments.All(x => IsUnmanaged(x));
    //            if(areGenericTypesAllBlittable)
    //                result = t.GetFields(BindingFlags.Public |
    //                                     BindingFlags.NonPublic | BindingFlags.Instance)
    //                          .All(x => IsUnmanaged(x.FieldType));
    //            else
    //                return false;
    //        }
    //        else
    //            if(t.IsValueType)
    //            result = t.GetFields(BindingFlags.Public |
    //                                 BindingFlags.NonPublic | BindingFlags.Instance)
    //                      .All(x => IsUnmanaged(x.FieldType));

    //        _cache.Add(t, result);
    //        return result;
    //    }
    //public class TypeCache<T> {
    //    public static readonly Type Type = typeof(T);

    //    public static readonly bool IsUnmanaged = Type.IsUnmanaged();
    //}
    //}
    /// <summary>
    /// A utility class for reflection related stuff
    /// </summary>
    internal static class ReflectionUtils {
        //private static readonly SerializerOptions DefaultSerializerOptions = new();

        /// <summary>
        /// Determines whether the specified type is basic type. A basic type is one that can be wholly expressed
        /// as an XML attribute. All primitive data types and type <c>string</c> and <c>DataTime</c> are basic.
        /// </summary>
        /// <param name="t">The type to check.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type is a basic type; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsBasicType(Type t) {
            if(t == typeof(string) || t.IsPrimitive || t.IsEnum || t == typeof(DateTime) || t == typeof(decimal) ||
                t == typeof(Guid))
                return true;
            Type nullableValueType;
            if(IsNullable(t, out nullableValueType) && nullableValueType != null)
                return IsBasicType(nullableValueType);

            return false;
        }

        /// <summary>
        /// Determines whether the specified type is array.
        /// </summary>
        /// <param name="type">The type to check</param>
        /// <param name="elementType">Type of the containing element.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type is array; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsArray(Type type, out Type elementType) {
            if(type.IsArray) {
                elementType = type.GetElementType();
                return true;
            }

            if(type == typeof(Array)) // i.e., a direct ref to System.Array
            {
                elementType = typeof(object);
                return true;
            }

            elementType = typeof(object);
            return false;
        }

        /// <summary>
        /// Determines whether the specified type is array.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        /// <c>true</c> if the specified type is array; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsArray(Type type) {
            Type _;
            return IsArray(type, out _);
        }

        /// <summary>
        /// Gets the array dimensions.
        /// </summary>
        /// <param name="ar">The array to return its dimensions.</param>
        /// <returns>the specified array's dimensions</returns>
        static int[] GetArrayDimensions(object ar) {
            //    var dims = Array.Empty<int>();
            //    if(IsArray(ar.GetType()) && ar is Array arObj)
            //{
            //        dims = new int[arObj.Rank];
            //        for(var i = 0; i < dims.Length; i++)
            //            dims[i] = arObj.GetLength(i);
            //    }

            //    return dims;
            throw new Exception();
        }

        /// <summary>
        /// Gets the friendly name for the type. Recommended for generic types.
        /// </summary>
        /// <param name="type">The type to get its friendly name</param>
        /// <returns>The friendly name for the type</returns>
        static string GetTypeFriendlyName(Type type) {
            //    if(type == null)
            //        throw new ArgumentNullException(nameof(type));

            //    var name = type.Name;
            //    if(type.IsGenericType) {
            //        var backTickIndex = name.IndexOf('`');
            //        //name = backTickIndex switch {
            //        //0 => throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
            //        //    "Bad type name: {0}", name)),
            //        //> 0 => name.Substring(0, backTickIndex),
            //        //_ => name
            //        //};

            //    using var poolObject = StringBuilderPool.Instance.Get(out var sb);
            //    sb.Append(name);
            //    sb.Append("Of");
            //    foreach(var genType in type.GetGenericArguments())
            //        sb.Append(GetTypeFriendlyName(genType));
            //    name = sb.ToString();
            //}
            //else if (type.IsArray)
            //{
            //    var t = type.GetElementType();
            //name = string.Format(CultureInfo.InvariantCulture, "Array{0}Of{1}", type.GetArrayRank(),
            //        GetTypeFriendlyName(t));
            //}

            //return name;
            throw new Exception();
        }

        /// <summary>
        /// Determines whether the type specified contains generic parameters or not.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        ///     <value><c>true</c> if the type contains generic parameters; otherwise,<c>false</c>.</value>
        /// </returns>
        public static bool TypeContainsGenericParameters(Type type) {
            if(type == null)
                throw new ArgumentNullException(nameof(type));

            if(type.IsGenericType)
                foreach(var genType in type.GetGenericArguments())
                    if(genType.IsGenericParameter)
                        return true;
                    else if(TypeContainsGenericParameters(genType))
                        return true;

            return false;
        }

        /// <summary>
        /// Determines whether the specified type is a collection type, i.e., it implements IEnumerable.
        /// Although System.String is derived from IEnumerable, it is considered as an exception.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type is a collection type; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsCollectionType(Type type) {
            if(type == typeof(string))
                return false;

            return IsIEnumerable(type);
        }

        public static bool IsDerivedFromGenericInterfaceType(Type givenType, Type genericInterfaceType,
            out Type genericType) {
            genericType = null;
            if((givenType.IsClass || givenType.IsValueType) && !givenType.IsAbstract)
                foreach(var interfaceType in givenType.GetInterfaces())
                    if(interfaceType.IsGenericType &&
                        interfaceType.GetGenericTypeDefinition() == genericInterfaceType) {
                        var genArgs = interfaceType.GetGenericArguments();
                        if(genArgs.Length != 1)
                            return false;

                        genericType = genArgs[0];
                        return true;
                    }

            return false;
        }

        /// <summary>
        /// Determines whether the specified type has implemented or is an <c>IEnumerable</c> or <c>IEnumerable&lt;&gt;</c>
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type is enumerable; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsIEnumerable(Type type) {
            Type _;
            return IsIEnumerable(type, out _);
        }

        /// <summary>
        /// Determines whether the specified type has implemented or is an <c>IEnumerable</c> or <c>IEnumerable&lt;&gt;</c> .
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <param name="seqType">Type of the sequence items.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type is enumerable; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsIEnumerable(Type type, out Type seqType) {
            // detect arrays early
            if(IsArray(type, out seqType))
                return true;

            seqType = typeof(object);
            if(type == typeof(IEnumerable))
                return true;

            var isNonGenericEnumerable = false;

            if(type.IsInterface && type.IsGenericType && type.GetGenericTypeDefinition() == typeof(IEnumerable<>)) {
                seqType = type.GetGenericArguments()[0];
                return true;
            }

            foreach(var interfaceType in type.GetInterfaces())
                if(interfaceType.IsGenericType &&
                    interfaceType.GetGenericTypeDefinition() == typeof(IEnumerable<>)) {
                    var genArgs = interfaceType.GetGenericArguments();
                    seqType = genArgs[0];
                    return true;
                }
                else if(interfaceType == typeof(IEnumerable)) {
                    isNonGenericEnumerable = true;
                }

            // the second case is a direct reference to IEnumerable
            if(isNonGenericEnumerable || type == typeof(IEnumerable)) {
                seqType = typeof(object);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the type of the items of a collection type.
        /// </summary>
        /// <param name="type">The type of the collection.</param>
        /// <returns>The type of the items of a collection type.</returns>
        public static Type GetCollectionItemType(Type type) {
            Type itemType;
            if(IsIEnumerable(type, out itemType))
                return itemType;
            throw new ArgumentException("The specified type must be a collection", nameof(type));
        }

        /// <summary>
        /// Determines whether the specified type has implemented <c>IList</c>.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type has implemented <c>IList</c>; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsIList(Type type) {
            // a direct reference to the interface itself is also OK.
            if(type.IsInterface && type.GetGenericTypeDefinition() == typeof(IList<>))
                return true;

            foreach(var interfaceType in type.GetInterfaces())
                if(interfaceType.IsGenericType &&
                    interfaceType.GetGenericTypeDefinition() == typeof(IList<>))
                    return true;

            return false;
        }

        /// <summary>
        /// Determines whether the specified type has implemented the <c>ICollection</c> interface.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <param name="itemType">Type of the member items.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type has implemented the <c>ICollection</c> interface; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsICollection(Type type, out Type itemType) {
            itemType = typeof(object);

            // a direct reference to the interface itself is also OK.
            if(type.IsInterface && type.GetGenericTypeDefinition() == typeof(ICollection<>)) {
                itemType = type.GetGenericArguments()[0];
                return true;
            }

            foreach(var interfaceType in type.GetInterfaces())
                if(interfaceType.IsGenericType &&
                    interfaceType.GetGenericTypeDefinition() == typeof(ICollection<>)) {
                    itemType = interfaceType.GetGenericArguments()[0];
                    return true;
                }

            return false;
        }

        /// <summary>
        /// Determines whether the specified type is a generic dictionary.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <param name="keyType">Type of the key.</param>
        /// <param name="valueType">Type of the value.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type has implemented the IDictionary interface; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsIDictionary(Type type, out Type keyType, out Type valueType) {
            keyType = typeof(object);
            valueType = typeof(object);

            // a direct reference to the interface itself is also OK.
            if(type.IsInterface && type.IsGenericType && type.GetGenericTypeDefinition() == typeof(IDictionary<,>)) {
                var genArgs = type.GetGenericArguments();
                keyType = genArgs[0];
                valueType = genArgs[1];
                return true;
            }

            foreach(var interfaceType in type.GetInterfaces())
                if(interfaceType.IsGenericType &&
                    interfaceType.GetGenericTypeDefinition() == typeof(IDictionary<,>)) {
                    var genArgs = interfaceType.GetGenericArguments();
                    keyType = genArgs[0];
                    valueType = genArgs[1];
                    return true;
                }

            return false;
        }

        /// <summary>
        /// Determines whether the specified type is a generic dictionary.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type is dictionary; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsIDictionary(Type type) {
            Type _1, _2;
            return IsIDictionary(type, out _1, out _2);
        }

        /// <summary>
        /// Determines whether the specified type is a non generic IDictionary, e.g., a Hashtable.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        /// <c>true</c> if the specified type is a non generic IDictionary; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNonGenericIDictionary(Type type) {
            // a direct reference to the interface itself is also OK.
            if(type == typeof(IDictionary))
                return true;

            foreach(var interfaceType in type.GetInterfaces())
                if(interfaceType == typeof(IDictionary))
                    return true;

            return false;
        }

        /// <summary>
        /// Determines whether the specified type is equal to this type,
        /// or is a nullable of this type, or this type is a nullable of
        /// the other type.
        /// </summary>
        /// <param name="self"></param>
        /// <param name="other"></param>
        /// <returns></returns>
        public static bool EqualsOrIsNullableOf(this Type self, Type other) {
            if(self == other)
                return true;
            Type selfBaseType;
            if(!IsNullable(self, out selfBaseType))
                selfBaseType = self;
            Type otherBaseType;
            if(!IsNullable(other, out otherBaseType))
                otherBaseType = other;

            return selfBaseType == otherBaseType;
        }

#pragma warning disable S3776 // disable sonar cognitive complexity warnings
        /// <summary>
        /// Determines whether the specified type is equal or inherited from another specified type.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <param name="baseType">
        /// Another type that the specified type is checked whether it is equal or
        /// has been driven from.
        /// </param>
        /// <returns>
        /// <c>true</c> if the specified type is equal or inherited from another specified type; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsTypeEqualOrInheritedFromType(Type type, Type baseType) {
            if(type == baseType)
                return true;

            var isTypeGenDef = type.IsGenericTypeDefinition;
            var isBaseGenDef = baseType.IsGenericTypeDefinition;
            Type[] typeGenArgs = null;
            Type[] baseGenArgs = null;

            if(type.IsGenericType) {
                if(isBaseGenDef) {
                    if(!isTypeGenDef) {
                        type = type.GetGenericTypeDefinition();
                        isTypeGenDef = true;
                    }
                }
                else {
                    typeGenArgs = type.GetGenericArguments();
                }
            }

            if(baseType.IsGenericType) {
                if(isTypeGenDef) {
                    if(!isBaseGenDef) {
                        baseType = baseType.GetGenericTypeDefinition();
                    }
                }
                else {
                    baseGenArgs = baseType.GetGenericArguments();
                }
            }

            if(type == baseType)
                return true;

            if(typeGenArgs != null && baseGenArgs != null) {
                if(typeGenArgs.Length != baseGenArgs.Length)
                    return false;

                for(var i = 0; i < typeGenArgs.Length; i++)
                    // Should this method be called for type args recursively?
                    if(typeGenArgs[i] != baseGenArgs[i])
                        return false;
            }

            if(baseType.IsInterface) {
                foreach(var iface in type.GetInterfaces())
                    if(iface.Name == baseType.Name)
                        return true;
                return false;
            }

            var curBaseType = type.BaseType;
            while(curBaseType != null) {
                if(curBaseType.Name == baseType.Name)
                    return true;

                curBaseType = curBaseType.BaseType;
            }

            return false;
        }

        /// <summary>
        /// Converts the specified object from a basic type to another type as specified.
        /// It is meant by basic types, primitive data types, strings, and enums.
        /// </summary>
        /// <param name="value">The object to be converted.</param>
        /// <param name="dstType">the destination type of conversion.</param>
        /// <param name="culture">The <see cref="CultureInfo" /> to use for culture-specific value formats.</param>
        /// <returns>the converted object</returns>
        static object ConvertBasicType(object value, Type dstType, CultureInfo culture) {
            //object convertedObj;
            //if(dstType.IsEnum) {
            //    var typeWrapper = UdtWrapperCache.Instance.GetOrAddItem(dstType, DefaultSerializerOptions);
            //    convertedObj = typeWrapper.EnumWrapper!.ParseAlias(value.ToString());
            //}
            //else if(dstType == typeof(DateTime)) {
            //    convertedObj = StringUtils.ParseDateTimeTimeZoneSafe(value.ToString(), culture);
            //}
            //else if(dstType == typeof(decimal)) {
            //    // to fix the asymmetry of used locales for this type between serialization and deserialization
            //    convertedObj = Convert.ChangeType(value, dstType, culture);
            //}
            //else if(dstType == typeof(bool)) {
            //    var strValue = value.ToString().Trim().ToLower();
            //    if(strValue == "false" || strValue == "no" || strValue == "0") {
            //        convertedObj = false;
            //    }
            //    else if(strValue == "true" || strValue == "yes" || strValue == "1") {
            //        convertedObj = true;
            //    }
            //    else {
            //        if(int.TryParse(strValue, out var boolIntValue))
            //            convertedObj = boolIntValue != 0;
            //        else
            //            throw new ArgumentException($"The specified value {strValue} is not recognized as boolean",
            //                nameof(value));
            //    }
            //}
            //else if(dstType == typeof(Guid)) {
            //    return new Guid(value.ToString());
            //}
            //else {
            //    if(IsNullable(dstType, out var nullableType)) {
            //        if(value.ToString() == string.Empty)
            //            return null;

            //        return ConvertBasicType(value, nullableType!, culture);
            //    }

            //    convertedObj = Convert.ChangeType(value, dstType, culture);
            //}

            //return convertedObj;
            throw new Exception();
        }
#pragma warning restore S3776 // enable sonar cognitive complexity warnings

        public static bool IsNumeric(this Type type) {
            //if (type == null)
            //    return false;

            switch(Type.GetTypeCode(type)) {
                case TypeCode.SByte:
                case TypeCode.Byte:
                case TypeCode.Int16:
                case TypeCode.UInt16:
                case TypeCode.Int32:
                case TypeCode.UInt32:
                case TypeCode.Int64:
                case TypeCode.UInt64:
                case TypeCode.Single:
                case TypeCode.Double:
                case TypeCode.Decimal:
                    return true;
                case TypeCode.Object:
                    if(type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                        return Nullable.GetUnderlyingType(type).IsNumeric();
                    return false;
            }
            return false;
        }
        public static bool IsInstanceOfSameGeneric(this Type type, Type genericType) {
            genericType = genericType.IsGenericType ? genericType.GetGenericTypeDefinition() : genericType;
            return type.IsGenericType && type.GetGenericTypeDefinition() == genericType;
        }
        /// <summary>
        /// Determines whether the specified type is nullable.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        /// <c>true</c> if the specified type is nullable; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNullable(Type type) {
            Type _;
            return IsNullable(type, out _);
        }

        /// <summary>
        /// Determines whether the specified type is nullable.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <param name="valueType">The value type of the corresponding nullable type.</param>
        /// <returns>
        /// <c>true</c> if the specified type is nullable; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNullable(Type type, out Type valueType) {
            if(type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>)) {
                valueType = type.GetGenericArguments()[0];
                return true;
            }

            valueType = null;
            return false;
        }

        /// <summary>
        /// Determines whether the specified type implements <c>IFormattable</c>
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        /// <c>true</c> if the specified type implements <c>IFormattable</c>; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsIFormattable(Type type) {
            // a direct reference to the interface itself is also OK.
            if(type == typeof(IFormattable))
                return true;

            foreach(var interfaceType in type.GetInterfaces())
                if(interfaceType == typeof(IFormattable))
                    return true;

            return false;
        }

        /// <summary>
        /// Determines whether the type provides the functionality
        /// to format the value of an object into a string representation.
        /// </summary>
        /// <param name="type">The type to check.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type implements the <c>IFormattable</c> interface; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool IsStringConvertibleIFormattable(Type type) {
            // is IFormattable
            // accept parameterless ToString
            // accept ctor of string
            if(IsIFormattable(type)
                && !HasOneReadWriteProperty(type)
                && null != type.GetConstructor(new[] { typeof(string) })
                && null != type.GetMethod("ToString", Type.EmptyTypes)
                && null != type.GetMethod("ToString", new[] { typeof(string) }))
                return true;

            return false;
        }

        /// <summary>
        /// Checks to see if the specified type has readable and writable properties.
        /// </summary>
        /// <param name="type">The type to check for.</param>
        /// <returns>
        ///     <value><c>true</c> if the specified type has readable and writable properties; otherwise, <c>false</c>.</value>
        /// </returns>
        public static bool HasOneReadWriteProperty(Type type) {
            var props = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach(var pi in props)
                if(pi.CanRead && pi.CanWrite) {
                    var getPi = pi.GetGetMethod(false);
                    var setPi = pi.GetSetMethod(false);
                    if(setPi != null && getPi != null)
                        return true;
                }

            return false;
        }

        /// <summary>
        /// Tries to format the specified object using the format string provided.
        /// If the formatting operation is not applicable, the source object is returned intact.
        /// Note: The type of the returned object will be 'System.String' if formatting succeeds.
        /// </summary>
        /// <param name="src">The source object.</param>
        /// <param name="format">The format string.</param>
        /// <returns><code>System.String</code> if the format is successful; otherwise, the original object</returns>
        public static object TryFormatObject(object src, string format) {
            if(format == null || src == null)
                return src;

            object formattedObject;

            try {
                formattedObject = src.GetType().InvokeMember("ToString", BindingFlags.InvokeMethod,
                    null, src, new object[] { format });
            }
            catch {
                return src;
            }

            return formattedObject ?? src;
        }

        /// <summary>
        /// Searches all loaded assemblies to find a type with a special name.
        /// </summary>
        /// <remarks>
        /// Types from System.Private.CoreLib (NETSTANDARD, NET5.0) the corresponding type from mscorlib (NETFRAMEWORK)
        /// will be returned and vice versa, depending on the framework the executing assembly is compiled for.
        /// </remarks>
        /// <param name="name">The <see cref="Type.AssemblyQualifiedName" /> of the type to find.</param>
        /// <returns><see cref="Type" /> found using the specified name</returns>
        static Type GetTypeByName(string name) {
            //var pattern =
            //    RuntimeInformation.FrameworkDescription.StartsWith(".NET Framework")
            //        // Forward compatibility:
            //        // if we get a yaxlib:realtype which is NETSTANDARD (and later) System.Private.CoreLib, replace it with its equivalent
            //        ? @"\,\s+(System\.Private\.CoreLib)\,\s+Version\=\d+(\.\d+)*\,\s+Culture=\b\w+\b\,\s+PublicKeyToken\=\b\w+\b"
            //        // Backward compatibility:
            //        // if we get a yaxlib:realtype which is .Net Framework 2.x/3.x/4.x mscorlib, replace it with its equivalent
            //        : @"\,\s+(mscorlib)\,\s+Version\=\d+(\.\d+)*\,\s+Culture=\b\w+\b\,\s+PublicKeyToken\=\b\w+\b";

            //var execAppFxName =
            //    Regex.Replace(name, pattern, name.GetType().Assembly.FullName,
            //        RegexOptions.None, TimeSpan.FromMilliseconds(100));

            //var assemblies = AppDomain.CurrentDomain.GetAssemblies();

            //// first search the 1st assembly (i.e. the mscorlib), then start from the last assembly backward,
            //// the last assemblies are user defined ones
            //for(var i = assemblies.Length; i > 0; i--) {
            //    var curAssembly = i == assemblies.Length ? assemblies[0] : assemblies[i];

            //    try {
            //        var type = curAssembly.GetType(execAppFxName, false, true);
            //        if(type != null)
            //            return type;
            //    }
            //    catch {
            //        // ignored
            //    }
            //}

            return null;
        }

        /// <summary>
        /// Determines whether the specified property is public.
        /// </summary>
        /// <param name="pi">The property.</param>
        /// <returns>
        /// <c>true</c> if the specified property is public; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsPublicProperty(PropertyInfo pi) {
            foreach(var m in pi.GetAccessors())
                if(m.IsPublic)
                    return true;

            return false;
        }

        /// <summary>
        /// Test whether the <see cref="MemberInfo" /> parameter is part of a .NET assembly.
        /// </summary>
        /// <remarks>
        /// Might require modifications when supporting future versions of .NET.
        /// </remarks>
        /// <param name="memberInfo"></param>
        /// <returns>
        /// Returns <see langword="true" />, if the <see cref="MemberInfo" /> parameter is part of a .NET assembly, else
        /// <see langword="false" />.
        /// </returns>
        public static bool IsPartOfNetFx(MemberInfo memberInfo) {
            var assemblyName = memberInfo.DeclaringType.Assembly.GetName().Name;
#if NETSTANDARD
            return assemblyName.StartsWith("System.", StringComparison.OrdinalIgnoreCase) ||
                   assemblyName.StartsWith("mscorlib.", StringComparison.OrdinalIgnoreCase) ||
                   assemblyName.StartsWith("Microsoft.", StringComparison.OrdinalIgnoreCase);
#else
            return assemblyName.Equals("mscorlib", StringComparison.OrdinalIgnoreCase)
                   || assemblyName.Equals("System", StringComparison.OrdinalIgnoreCase)
                   || assemblyName.Equals("System.Core", StringComparison.OrdinalIgnoreCase);
#endif
        }

        public static bool IsInstantiableCollection(Type colType) {
            return colType.GetConstructor(Type.EmptyTypes) != null;
        }

        public static T InvokeGetProperty<T>(object srcObj, string propertyName) {
            return (T)srcObj.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance)
                ?.GetValue(srcObj, null);
        }

        public static T InvokeIntIndexer<T>(object srcObj, int index) {
            var pi = srcObj.GetType().GetProperty("Item", new[] { typeof(int) });
            return (T)pi?.GetValue(srcObj, new object[] { index });
        }

        public static object InvokeStaticMethod(Type type, string methodName, params object[] args) {
            var argTypes = Select(args, x => x.GetType()).ToArray();//args.Select(x => x.GetType()).ToArray();
            var method = type.GetMethod(methodName, argTypes);
            var result = method?.Invoke(null, args);
            return result;
        }

        public static object InvokeMethod(object srcObj, string methodName, params object[] args) {
            var argTypes = Select(args, x => x.GetType()).ToArray(); //args.Select(x => x.GetType()).ToArray();
            var method = srcObj.GetType().GetMethod(methodName, argTypes);
            var result = method?.Invoke(srcObj, args);
            return result;
        }
        static List<Type> Select(object[] args, Func<object, Type> func) {
            List<Type> os = new List<Type>();
            //int counter = 0;
            foreach(var element in args) {
                //yield return selector(element, counter);
                os.Add(func(element));
                //counter++;
            }
            return os;
        }
#pragma warning disable S3011 // disable sonar accessibility bypass warning: private members are intended

        /// <summary>
        /// Gets the value for a public or non-public instance field.
        /// Including private fields in base types is optional, and enabled by default.
        /// </summary>
        /// <param name="target"></param>
        /// <param name="fieldName"></param>
        /// <param name="includePrivateBaseTypeFields"></param>
        public static object GetFieldValue(object target, string fieldName, bool includePrivateBaseTypeFields = true) {
            var field = target.GetType().GetField(fieldName,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if(field == null && includePrivateBaseTypeFields)
                field = GetPrivateBaseField(target.GetType(), fieldName);
            return field.GetValue(target);
        }

        /// <summary>
        /// Sets the value for a public or non-public instance field..
        /// Including private fields in base types is optional, and enabled by default.
        /// </summary>
        /// <param name="target"></param>
        /// <param name="fieldName"></param>
        /// <param name="value"></param>
        /// <param name="includePrivateBaseTypeFields"></param>
        public static void SetFieldValue(object target, string fieldName, object value,
            bool includePrivateBaseTypeFields = true) {
            var field = target.GetType().GetField(fieldName,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if(field == null && includePrivateBaseTypeFields)
                field = GetPrivateBaseField(target.GetType(), fieldName);
            field.SetValue(target, value);
        }

        /// <summary>
        /// Gets the value for a public or non-public instance property.
        /// Including private properties in base types is optional, and enabled by default.
        /// </summary>
        public static object GetPropertyValue(object target, string propertyName,
            bool includePrivateBaseTypeProperties = true) {
            var property = target.GetType().GetProperty(propertyName,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if(property == null && includePrivateBaseTypeProperties)
                property = GetPrivateBaseProperty(target.GetType(), propertyName);
            return property.GetValue(target, null);
        }

        /// <summary>
        /// Sets the value for a public or non-public instance property.
        /// Including private properties in base types is optional, and enabled by default.
        /// </summary>
        public static void SetPropertyValue(object target, string propertyName, object value,
            bool includePrivateBaseTypeProperties = true) {
            var property = target.GetType().GetProperty(propertyName,
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if(property == null && includePrivateBaseTypeProperties)
                property = GetPrivateBaseProperty(target.GetType(), propertyName);
            property.SetValue(target, value, null);
        }

        private static FieldInfo GetPrivateBaseField(Type type, string fieldName) {
            var currentType = type;
            while((currentType = currentType.BaseType) != null) {
                var field = currentType.GetField(fieldName,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if(field != null)
                    return field;
            }

            return null;
        }

        private static PropertyInfo GetPrivateBaseProperty(Type type, string propertyName) {
            var currentType = type;
            while((currentType = currentType.BaseType) != null) {
                var property = currentType.GetProperty(propertyName,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if(property != null)
                    return property;
            }

            return null;
        }

#pragma warning restore S3011 // restore sonar accessibility bypass warning

        public static bool IsBaseClassOrSubclassOf(Type subType, string baseName) {
            if(baseName == null || subType == null)
                return false;
            var baseType = Type.GetType(baseName);
            return baseType != null && (subType.FullName == baseName || subType.IsSubclassOf(baseType));
        }
    }

    /// <summary>
    /// Various extension methods for type reflection.
    /// https://github.com/dotnet/dotNext/blob/master/src/DotNext/Reflection/TypeExtensions.cs
    /// </summary>
    //public static class TypeExtensions 
}