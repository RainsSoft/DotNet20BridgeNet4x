﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace DotNetCross.Runtime.CompilerServices {
    //public unsafe static class Unsafe {
    //    // Methods
    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    //[MethodImpl(0x100), NonVersionable]
    //    //public static ref T Add<T>(ref T source, int elementOffset) {
    //    //    return (source + (elementOffset * ((IntPtr)sizeof(T))));
    //    //}    
    //    //[MethodImpl(0x100), NonVersionable]
    //    //public static  T Add<T>(ref T source, int elementOffset) {
    //    //    unsafe
    //    //    {
    //    //        IntPtr p = IntPtr.Zero;
    //    //        using(var buf = Memory.PinObject(source)) {
    //    //            buf.Offset(elementOffset*SizeOfTEx.SizeOf<T>());
    //    //            p = (IntPtr)buf.Ptr;
    //    //        }
    //    //        return (T)Marshal.PtrToStructure(p, typeof(T));
    //    //    }
          
    //    //}
    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void* Add<T>(void* source, int elementOffset) {
    //        //return (source + (elementOffset * sizeof(T)));
    //        byte* p = (byte*)source;
    //        return p + (elementOffset * Memory.SizeOf(default(T)));            
    //    }

    //    //// WARNING: Selected version of C# does not support "by-ref" return.
    //    //[MethodImpl(0x100), NonVersionable]
    //    //public static ref T Add<T>(ref T source, IntPtr elementOffset) {
    //    //    return (source + (elementOffset * sizeof(T)));
    //    //}

    //    //// WARNING: Selected version of C# does not support "by-ref" return.
    //    //[MethodImpl(0x100)]
    //    //public static ref T Add<T>(ref T source, [NativeInteger, NonVersionable] UIntPtr elementOffset) {
    //    //    return (source + (elementOffset * sizeof(T)));
    //    //}

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref T AddByteOffset<T>(ref T source, IntPtr byteOffset) {
    //        return (source + byteOffset);
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100)]
    //    public static ref T AddByteOffset<T>(ref T source, [NonVersionable, NativeInteger] UIntPtr byteOffset) {
    //        return (source + byteOffset);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static bool AreSame<T>(ref T left, ref T right) {
    //        return (left == right);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static T As<T>(object o) where T : class {
    //        return (T)o;
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref TTo As<TFrom, TTo>(ref TFrom source) {
    //        return source;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void* AsPointer<T>(ref T value) {
    //        return (void*)value;
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe ref T AsRef<T>(void* source) {
    //    ref int numRef = (int)source;
    //        return (T)numRef;
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref T AsRef<T>([IsReadOnly] ref T source) {
    //        return source;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static IntPtr ByteOffset<T>(ref T origin, ref T target) {
    //        return (target - origin);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void Copy<T>(void* destination, ref T source) {
    //        destination[0] = source;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void Copy<T>(ref T destination, void* source) {
    //        destination = (T)source[0];
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void CopyBlock(void* destination, void* source, uint byteCount) {
    //        memcpy(destination, source, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static void CopyBlock(ref byte destination, ref byte source, uint byteCount) {
    //        memcpy(destination, source, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void CopyBlockUnaligned(void* destination, void* source, uint byteCount) {
    //        memcpy(destination, source, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static void CopyBlockUnaligned(ref byte destination, ref byte source, uint byteCount) {
    //        memcpy(destination, source, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void InitBlock(void* startAddress, byte value, uint byteCount) {
    //        meminit(startAddress, value, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static void InitBlock(ref byte startAddress, byte value, uint byteCount) {
    //        meminit(startAddress, value, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void InitBlockUnaligned(void* startAddress, byte value, uint byteCount) {
    //        meminit(startAddress, value, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static void InitBlockUnaligned(ref byte startAddress, byte value, uint byteCount) {
    //        meminit(startAddress, value, byteCount);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static bool IsAddressGreaterThan<T>(ref T left, ref T right) {
    //        return (left > right);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static bool IsAddressLessThan<T>(ref T left, ref T right) {
    //        return (left < right);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static bool IsNullRef<T>(ref T source) {
    //        return (source == IntPtr.Zero);
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref T NullRef<T>() {
    //        return (T)IntPtr.Zero;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe T Read<T>(void* source) {
    //        return *(((T*)source));
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe T ReadUnaligned<T>(void* source) {
    //        return *(((T*)source));
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static T ReadUnaligned<T>(ref byte source) {
    //        return (T)source;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static int SizeOf<T>() {
    //        return sizeof(T);
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static void SkipInit<T>(out T value) {
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref T Subtract<T>(ref T source, int elementOffset) {
    //        return (source - (elementOffset * ((IntPtr)sizeof(T))));
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void* Subtract<T>(void* source, int elementOffset) {
    //        return (source - (elementOffset * sizeof(T)));
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref T Subtract<T>(ref T source, IntPtr elementOffset) {
    //        return (source - (elementOffset * sizeof(T)));
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100)]
    //    public static ref T Subtract<T>(ref T source, [NonVersionable, NativeInteger] UIntPtr elementOffset) {
    //        return (source - (elementOffset * sizeof(T)));
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref T SubtractByteOffset<T>(ref T source, IntPtr byteOffset) {
    //        return (source - byteOffset);
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100)]
    //    public static ref T SubtractByteOffset<T>(ref T source, [NativeInteger, NonVersionable] UIntPtr byteOffset) {
    //        return (source - byteOffset);
    //    }

    //    // WARNING: Selected version of C# does not support "by-ref" return.
    //    [MethodImpl(0x100), NonVersionable]
    //    public static ref T Unbox<T>(object box) where T : struct {
    //        return (T)box;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void Write<T>(void* destination, T value) {
    //        destination[0] = value;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static unsafe void WriteUnaligned<T>(void* destination, T value) {
    //        destination[0] = value;
    //    }

    //    [MethodImpl(0x100), NonVersionable]
    //    public static void WriteUnaligned<T>(ref byte destination, T value) {
    //        destination = value;
    //    }
    //}




    
}
