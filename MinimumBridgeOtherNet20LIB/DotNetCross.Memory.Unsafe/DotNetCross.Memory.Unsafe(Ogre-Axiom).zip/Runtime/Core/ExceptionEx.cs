﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetCross.Runtime.CompilerServices {
    /// <summary>
    /// Summary description for AxiomException.
    /// </summary>
    public class AxiomException : Exception {
        public AxiomException(string message, params object[] args)
            : base(string.Format(message, args)) {
        }

        public AxiomException(string message, Exception innerException, params object[] args)
            : base(string.Format(message, args), innerException) {
        }
    }
}
