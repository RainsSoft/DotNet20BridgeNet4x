﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetCross.Runtime.CompilerServices {
    public class AxiomHelperAttribute : Attribute {
        public AxiomHelperAttribute(int major, int minor)
            : this(major, minor, String.Empty) {
        }

        public AxiomHelperAttribute(int major, int minor, string comment) {
        }
    }
}
