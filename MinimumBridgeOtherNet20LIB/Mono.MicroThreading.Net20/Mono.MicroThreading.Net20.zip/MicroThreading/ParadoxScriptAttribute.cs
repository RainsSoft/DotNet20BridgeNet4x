﻿// Copyright (c) 2022 RainsSoft (https://github.com/RainsSoft)
// This file is distributed under GPL v3. See LICENSE.md for details.
using System;

namespace Mono.Core.MicroThreading
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public class ParadoxScriptAttribute : Attribute
    {
        public ParadoxScriptAttribute(ScriptFlags flags = ScriptFlags.None)
        {
            this.Flags = flags;
        }

        public ScriptFlags Flags { get; set; }
    }
}