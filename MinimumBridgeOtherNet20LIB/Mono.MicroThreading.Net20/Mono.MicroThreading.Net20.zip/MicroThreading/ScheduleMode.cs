﻿// Copyright (c) 2022 RainsSoft (https://github.com/RainsSoft)
// This file is distributed under GPL v3. See LICENSE.md for details.
namespace Mono.Core.MicroThreading
{
    public enum ScheduleMode
    {
        First,
        Last,
    }
}