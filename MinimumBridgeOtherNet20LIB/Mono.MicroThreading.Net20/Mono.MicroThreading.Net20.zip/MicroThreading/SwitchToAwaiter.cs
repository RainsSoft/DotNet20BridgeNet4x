﻿// Copyright (c) 2022 RainsSoft (https://github.com/RainsSoft)
// This file is distributed under GPL v3. See LICENSE.md for details.
using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace Mono.Core.MicroThreading
{
#if NET45
    public class SwitchToAwaiter : INotifyCompletion
#else
    public class SwitchToAwaiter
#endif
    {
        private Scheduler scheduler;

        private MicroThread microThread;

        public SwitchToAwaiter(Scheduler scheduler)
        {
            this.scheduler = scheduler;
            this.microThread = null;
        }

        public bool IsCompleted
        {
            get { return false; }
        }

        public void OnCompleted(Action continuation)
        {
            microThread = scheduler.Add(() => { continuation(); return Task.FromResult(true); });
        }

        public IDisposable GetResult()
        {
            return new SwitchMicroThread(microThread);
        }

        public SwitchToAwaiter GetAwaiter()
        {
            return this;
        }

        private struct SwitchMicroThread : IDisposable
        {
            private MicroThread microThread;

            public SwitchMicroThread(MicroThread microThread)
            {
                this.microThread = microThread;
                //microThread.SynchronizationContext.IncrementTaskCount();
            }

            public void Dispose()
            {
                //microThread.SynchronizationContext.DecrementTaskCount();
            }
        }
    }
}