## 1.1.1 (Released 2016/09/07)

* Make an assembly strong-named.

## 1.1.0 (Released 2015/12/10)

* Set AssemblyVersion to 1.0.0 to make a compatible dll.

## 1.0.3 (Released 2015/09/21)

* Initial Release
