﻿このフォルダー以下は[RackerLabs Task の .NET 3.5バックポーティング](https://github.com/rackerlabs/dotnet-threading)を参考に、
[Microsoft Reference Source](https://github.com/Microsoft/referencesource)からの借用。
