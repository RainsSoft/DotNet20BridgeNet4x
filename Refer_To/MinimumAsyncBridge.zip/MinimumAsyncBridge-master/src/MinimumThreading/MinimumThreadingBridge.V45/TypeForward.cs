﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

[assembly: TypeForwardedTo(typeof(AggregateException))]

[assembly: TypeForwardedTo(typeof(IProgress<>))]

[assembly: TypeForwardedTo(typeof(CancellationTokenSource))]
[assembly: TypeForwardedTo(typeof(CancellationToken))]
[assembly: TypeForwardedTo(typeof(CancellationTokenRegistration))]
