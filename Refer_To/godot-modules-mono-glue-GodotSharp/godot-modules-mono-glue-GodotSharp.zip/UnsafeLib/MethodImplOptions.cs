﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Godot.NativeInterop
{
   
    class MethodImplOptions
    {
        public const int AggressiveInlining = 0x100;
    }
}
