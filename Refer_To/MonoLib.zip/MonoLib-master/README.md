MonoLib
=======

Library with classes from Mono to bring modern C# language features to .NET 2.0


How to use
----------

To compile code with async/await in Visual Studio 2010 you need [Microsoft Async CTP](www.microsoft.com/en-us/download/details.aspx?id=9983)
Installation is a bit tricky, since you have to remove everything related to MVC3 and *all* updates to Visual Studio released after SP1

Contributing
------------

Please, indent with TABS, align with spaces.
