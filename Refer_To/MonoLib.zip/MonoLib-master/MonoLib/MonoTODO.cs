﻿using System;
using System.Collections.Generic;
using System.Text;


public class MonoTODOAttribute : System.Attribute
{
	public MonoTODOAttribute (string desc)
	{

	}

	public MonoTODOAttribute ()
	{

	}
}
