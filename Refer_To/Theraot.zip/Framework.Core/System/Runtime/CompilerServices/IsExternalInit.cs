﻿#if TARGETS_NET || TARGETS_NETSTANDARD || LESSTHAN_NET50

// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace System.Runtime.CompilerServices
{
    public static class IsExternalInit
    {
        // Empty
    }
}

#endif