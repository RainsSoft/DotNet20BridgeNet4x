﻿#if LESSTHAN_NET40

namespace System.Linq
{
    public enum ParallelExecutionMode
    {
        Default = 0,
        ForceParallelism = 1
    }
}

#endif