﻿using System;
using System.Collections.Generic;
using System.Text;

namespace System.corlib.Net20
{
    public class Class1
    {
    }
}
